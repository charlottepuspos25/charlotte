import hashlib
from datetime import datetime
from pathlib import Path

import joblib
import numpy as np
import pandas as pd
import plotly.express as px
import streamlit as st
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, confusion_matrix, classification_report
from sklearn.model_selection import train_test_split
from sklearn.tree import DecisionTreeClassifier

st.set_page_config(page_title="Campus Facility Reservation Monitor", page_icon="🏫", layout="wide")

REQUIRED_COLUMNS = [
    "Reservation_ID", "Facility_Type", "Facility_Name", "User_Category",
    "Lead_Time_Days", "Participants", "Usage_Status"
]
PREDICTORS = ["Facility_Type", "Facility_Name", "User_Category", "Lead_Time_Days", "Participants"]
TARGET = "Reservation_Outcome"
MODEL_PATH = Path("models/trained_model.joblib")

FACILITY_MAPPING = {
    "auditorium": "Auditorium", "AUDITORIUM": "Auditorium", "Auditorium": "Auditorium",
    "conf room": "Conference Room", "Conference Room": "Conference Room",
    "Lab": "Laboratory", "Laboratory": "Laboratory", "Gymnasium": "Gymnasium"
}
USER_MAPPING = {
    "student org": "Student Org", "Student Org": "Student Org", "STUDENT": "Student Org",
    "Faculty": "Faculty", "FACULTY": "Faculty", "External": "External", "Admin": "Admin"
}

@st.cache_data
def read_csv_bytes(raw_bytes):
    import io
    return pd.read_csv(io.BytesIO(raw_bytes))

def clean_data(raw):
    df = raw.copy()
    missing = [c for c in REQUIRED_COLUMNS if c not in df.columns]
    if missing:
        raise ValueError("Missing required columns: " + ", ".join(missing))
    if df.empty:
        raise ValueError("The uploaded CSV has no data rows.")

    df = df.drop_duplicates().reset_index(drop=True)
    df["Facility_Type"] = df["Facility_Type"].map(FACILITY_MAPPING).fillna(df["Facility_Type"])
    df["User_Category"] = df["User_Category"].map(USER_MAPPING).fillna(df["User_Category"])
    df["Facility_Type"] = df["Facility_Type"].fillna(df["Facility_Type"].mode().iloc[0] if not df["Facility_Type"].mode().empty else "Unknown")
    df["Facility_Name"] = df["Facility_Name"].fillna("Unknown")
    df["User_Category"] = df["User_Category"].fillna("Unknown")

    df["Participants"] = pd.to_numeric(df["Participants"], errors="coerce")
    valid_participants = df.loc[df["Participants"] > 0, "Participants"]
    median_participants = float(valid_participants.median()) if not valid_participants.empty else 1.0
    df.loc[df["Participants"] <= 0, "Participants"] = np.nan
    df["Participants"] = df["Participants"].fillna(median_participants)

    df["Lead_Time_Days"] = pd.to_numeric(df["Lead_Time_Days"], errors="coerce").fillna(0).clip(lower=0)
    if "Usage_Status" not in df.columns:
        raise ValueError("Usage_Status is required to derive the outcome target.")
    df[TARGET] = df["Usage_Status"].astype(str).str.strip().map(
        lambda x: "Completed" if x == "Used" else "Not Completed"
    )
    df["Lead_Time_Category"] = df["Lead_Time_Days"].apply(
        lambda d: "Last Minute" if d <= 2 else ("Short Lead" if d <= 7 else ("Medium Lead" if d <= 14 else "Early Booking"))
    )
    return df

def build_features(df):
    X = pd.get_dummies(df[PREDICTORS], drop_first=True)
    return X

@st.cache_resource
def train_cached_model(csv_digest, cleaned_csv):
    # The original notebook did not include a saved .joblib model in the supplied files.
    # This fallback repeats its stated feature list and DecisionTree settings on the uploaded dataset.
    import io
    data = pd.read_csv(io.StringIO(cleaned_csv))
    X = build_features(data)
    y = data[TARGET]
    if y.nunique() < 2 or len(data) < 5:
        raise ValueError("At least 5 rows and both outcome classes (Completed and Not Completed) are required to train.")
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.20, random_state=42, stratify=y
    )
    model = DecisionTreeClassifier(max_depth=4, criterion="gini", random_state=42)
    model.fit(X_train, y_train)
    pred = model.predict(X_test)
    metrics = {
        "accuracy": accuracy_score(y_test, pred),
        "precision": precision_score(y_test, pred, pos_label="Completed", zero_division=0),
        "recall": recall_score(y_test, pred, pos_label="Completed", zero_division=0),
        "f1": f1_score(y_test, pred, pos_label="Completed", zero_division=0),
        "confusion": confusion_matrix(y_test, pred, labels=["Completed", "Not Completed"]),
        "report": classification_report(y_test, pred, zero_division=0),
        "features": list(X.columns),
        "classes": list(model.classes_),
        "test_y": y_test,
        "test_pred": pred,
        "importances": pd.Series(model.feature_importances_, index=X.columns).sort_values(ascending=False),
    }
    return model, X.columns.tolist(), metrics

def make_prediction(model, feature_columns, facility_type, facility_name, user_category, lead_time, participants):
    row = pd.DataFrame([{
        "Facility_Type": facility_type,
        "Facility_Name": facility_name,
        "User_Category": user_category,
        "Lead_Time_Days": int(lead_time),
        "Participants": int(participants),
    }])
    encoded = pd.get_dummies(row, drop_first=True).reindex(columns=feature_columns, fill_value=0)
    pred = model.predict(encoded)[0]
    probs = model.predict_proba(encoded)[0] if hasattr(model, "predict_proba") else None
    return pred, probs

st.title("🏫 Campus Facility Reservation Monitoring")
st.caption("Midterm data-mining project · Cancellation / no-show early-warning decision support")
st.warning("Predictions support facility-administrator review only. Do not automatically reject reservations based on model output.")

with st.sidebar:
    st.header("Navigation")
    page = st.selectbox("Choose module", ["Home", "Dataset", "Data Analysis", "Prediction", "Dashboard", "System Design"])
    uploaded = st.file_uploader("Upload facility_reservations.csv", type=["csv"], key="dataset_upload")
    st.caption("Use synthetic or authorized data for public deployment.")

raw_df = None
df = None
model = None
feature_columns = []
metrics = None
if uploaded is not None:
    try:
        raw_df = read_csv_bytes(uploaded.getvalue())
        df = clean_data(raw_df)
        digest = hashlib.sha256(uploaded.getvalue()).hexdigest()
        model, feature_columns, metrics = train_cached_model(digest, df.to_csv(index=False))
        st.sidebar.success(f"Loaded {len(df):,} cleaned rows")
    except Exception as exc:
        st.error(f"Dataset/model issue: {exc}")

if page == "Home":
    st.subheader("System overview")
    st.write("This app converts the supplied midterm notebook workflow into a Streamlit interface for dataset validation, exploratory analysis, prediction, administrator review, and SAD documentation.")
    c1, c2, c3 = st.columns(3)
    c1.metric("Prediction target", "Reservation outcome")
    c2.metric("Positive class", "Completed")
    c3.metric("Model", "Decision Tree · max_depth=4")
    st.markdown("""
**Midterm predictors:** Facility_Type, Facility_Name, User_Category, Lead_Time_Days, Participants.

**Leakage controls:** Usage_Status is used only to derive the historical target. Actual_Attendance and Cancellation_Days_Before are not model inputs because they are post-event fields.

**Start here:** Upload the `facility_reservations.csv` generated by your notebook in the sidebar. The uploaded notebook did not include a separate CSV or saved model artifact, so this app can train the same Decision Tree settings from the uploaded data as a fallback.
""")
elif page == "Dataset":
    st.subheader("Dataset upload and validation")
    if raw_df is None:
        st.info("Upload a CSV in the sidebar to inspect it.")
    else:
        st.success("Required columns are present.")
        a,b,c = st.columns(3)
        a.metric("Raw rows", len(raw_df))
        a.metric("Columns", len(raw_df.columns))
        c.metric("Duplicate rows", int(raw_df.duplicated().sum()))
        st.markdown("**Raw data preview**")
        st.dataframe(raw_df.head(20), use_container_width=True)
        st.markdown("**Missing values by column**")
        st.dataframe(raw_df.isna().sum().rename("Missing values").to_frame(), use_container_width=True)
        st.markdown("**Cleaned data preview**")
        st.dataframe(df.head(20), use_container_width=True)
        st.download_button("Download cleaned CSV", df.to_csv(index=False).encode("utf-8"), "clean_facility_reservations.csv", "text/csv")
elif page == "Data Analysis":
    st.subheader("Exploratory data analysis")
    if df is None:
        st.info("Upload a valid CSV in the sidebar first.")
    else:
        st.write("Descriptive statistics")
        st.dataframe(df.describe(include="all").transpose(), use_container_width=True)
        f1 = px.bar(df["Facility_Type"].value_counts().rename_axis("Facility_Type").reset_index(name="Bookings"),
                    x="Facility_Type", y="Bookings", title="1. Reservation volume by facility type")
        st.plotly_chart(f1, use_container_width=True)
        f2data = pd.crosstab(df["User_Category"], df[TARGET], normalize="index").reset_index().melt(id_vars="User_Category", var_name="Outcome", value_name="Share")
        f2 = px.bar(f2data, x="User_Category", y="Share", color="Outcome", barmode="group", title="2. Outcome share by user category")
        st.plotly_chart(f2, use_container_width=True)
        lead_order = ["Last Minute", "Short Lead", "Medium Lead", "Early Booking"]
        f3data = pd.crosstab(df["Lead_Time_Category"], df[TARGET], normalize="index").reindex(lead_order).fillna(0).reset_index().melt(id_vars="Lead_Time_Category", var_name="Outcome", value_name="Share")
        f3 = px.bar(f3data, x="Lead_Time_Category", y="Share", color="Outcome", barmode="stack", title="3. Outcome share by lead-time category")
        st.plotly_chart(f3, use_container_width=True)
        f4 = px.histogram(df, x="Participants", color=TARGET, title="4. Expected participants by outcome")
        st.plotly_chart(f4, use_container_width=True)
        st.caption("Charts describe the uploaded data. Do not treat synthetic-data patterns as verified campus behavior.")
elif page == "Prediction":
    st.subheader("Predict a reservation outcome")
    if model is None:
        st.info("Upload a valid dataset with both target classes to enable predictions.")
    else:
        with st.form("prediction_form"):
            left, right = st.columns(2)
            facility_type = left.selectbox("Facility type", sorted(df["Facility_Type"].dropna().astype(str).unique()))
            facility_name = right.selectbox("Facility name", sorted(df["Facility_Name"].dropna().astype(str).unique()))
            user_category = left.selectbox("User category", sorted(df["User_Category"].dropna().astype(str).unique()))
            lead_time = right.number_input("Lead time (days)", min_value=0, max_value=365, value=7, step=1)
            participants = left.number_input("Expected participants", min_value=1, max_value=10000, value=30, step=1)
            submitted = st.form_submit_button("Predict outcome")
        if submitted:
            pred, probs = make_prediction(model, feature_columns, facility_type, facility_name, user_category, lead_time, participants)
            st.markdown(f"### Predicted outcome: **{pred}**")
            if probs is not None:
                prob_df = pd.DataFrame({"Class": model.classes_, "Model probability": probs})
                st.dataframe(prob_df, use_container_width=True)
                st.caption("Probability is model confidence, not a guarantee of the real-world outcome.")
            st.info("Recommended action: administrator reviews the request, checks details, and records the final decision. Prediction does not approve or reject the reservation.")
            st.caption(f"Prediction timestamp: {datetime.now().astimezone().isoformat(timespec='seconds')} · Model: DecisionTreeClassifier(max_depth=4, criterion='gini', random_state=42)")
        st.markdown("**Hold-out evaluation on the uploaded dataset**")
        m1,m2,m3,m4 = st.columns(4)
        m1.metric("Accuracy", f"{metrics['accuracy']:.3f}")
        m2.metric("Precision (Completed)", f"{metrics['precision']:.3f}")
        m3.metric("Recall (Completed)", f"{metrics['recall']:.3f}")
        m4.metric("F1 (Completed)", f"{metrics['f1']:.3f}")
        st.write("Confusion matrix (rows = actual; columns = predicted; class order: Completed, Not Completed)")
        st.dataframe(pd.DataFrame(metrics["confusion"], index=["Actual Completed","Actual Not Completed"], columns=["Pred Completed","Pred Not Completed"]))
        st.write("Top model features")
        st.dataframe(metrics["importances"].head(10).rename("Importance").to_frame())
elif page == "Dashboard":
    st.subheader("Facility administrator decision-support dashboard")
    if df is None:
        st.info("Upload a valid dataset in the sidebar to populate dashboard KPIs.")
    else:
        total = len(df)
        completed = int((df[TARGET] == "Completed").sum())
        not_completed = int((df[TARGET] == "Not Completed").sum())
        k1,k2,k3,k4 = st.columns(4)
        k1.metric("Reservations", total)
        k2.metric("Completed", completed)
        k3.metric("Cancelled / no-show", not_completed)
        k4.metric("Completion rate", f"{completed/total:.1%}" if total else "N/A")
        st.markdown("**Review queue — historical records with a non-completed outcome**")
        queue = df[df[TARGET] == "Not Completed"].copy()
        show_cols = [c for c in ["Reservation_ID","Facility_Type","Facility_Name","User_Category","Lead_Time_Days","Participants",TARGET] if c in queue.columns]
        st.dataframe(queue[show_cols].head(100), use_container_width=True)
        st.caption("This is a retrospective review list, not a claim that these records are pending. For real pending requests, connect an authorized live reservation source.")
        st.markdown("**Suggested human follow-up**")
        st.write("1. Verify reservation details and requester contact. 2. Ask for confirmation for short-lead bookings. 3. Review the model prediction alongside operational context. 4. Record the administrator's final decision and reason.")
elif page == "System Design":
    st.subheader("Systems Analysis and Design integration")
    st.markdown("### Actors")
    st.write("- Requester (student, faculty, external user): submits a reservation request.")
    st.write("- Facility Administrator: reviews request, sees analytics, and records final decision.")
    st.write("- Decision-support model: provides a predicted reservation outcome for review.")
    st.markdown("### Functional requirements")
    for req in [
        "FR-DM-01: The system shall identify last-minute bookings (0–2 days) for confirmation review.",
        "FR-DM-02: The system shall summarize historical non-completion rates by requester category for administrator review.",
        "FR-DM-03: The system shall display a model-predicted reservation outcome during request review.",
        "FR-DM-04: The system shall validate uploaded CSV schema and report missing required columns.",
        "FR-DM-05: The system shall show historical reservation KPIs and allow administrators to inspect records."
    ]:
        st.write("• " + req)
    st.markdown("### Non-functional requirements")
    st.write("- Usability: modules are accessible through clear sidebar navigation.")
    st.write("- Reliability: invalid/empty data is rejected with a meaningful message.")
    st.write("- Privacy and security: use synthetic or authorized data; restrict access to reservation records.")
    st.markdown("### Analytical workflow")
    st.code("CSV / reservation data → schema validation → cleaning and feature engineering → Decision Tree prediction → risk/outcome display → administrator review → human final decision", language="text")
    st.markdown("### Use case summary")
    st.write("Requester → Submit reservation request → Model predicts outcome → Facility administrator views prediction and analytics → Administrator verifies details and records final decision.")
    st.warning("The uploaded notebook contains a use-case specification in text, but no diagram image. Add your approved diagram to the repository if your instructor requires an image.")
